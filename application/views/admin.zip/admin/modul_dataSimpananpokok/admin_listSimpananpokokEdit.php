        <div class="content-wrapper">
          <!-- Content Header (Page header) -->
          <div class="content-header">
            <div class="container-fluid">
              <div class="row mb-2">
                <div class="col-sm-6">
                  <h1 class="m-0 text-dark"><?= $page ;?></h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                  <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><small><?= $this->session->userdata('level') ;?></small></li>
                    <li class="breadcrumb-item"><a href="<?= base_url('Admin/dataListSimpananpokok');?>"><small><?= $parent ;?></small></a></li>
                    <li class="breadcrumb-item"><a href="<?= base_url('Admin/dataListSimpananpokokEdit/'.$this->encrypt->encode($datasimpananpokok->id));?>"><small><?= $page ;?></small></a></li>
                  </ol>
                </div><!-- /.col -->
              </div><!-- /.row -->
              <?php if(validation_errors()) : ?>
                <!-- Row Note -->
                <div class="row">
                  <div class="col-12">
                    <div class="alert callout callout-info bg-danger" role="alert">
                      <h5><i class="fas fa-info"></i> Note:</h5>
                      <?= validation_errors(); ?>
                    </div>
                  </div>
                  <!--/. Col -->
                </div>
              <?php endif ;?>
              <?php if($this->session->flashdata('message') == TRUE) : ?>
                <!-- Row Note -->
                <div class="row">
                  <div class="col-12">
                    <div class="alert callout callout-info bg-danger" role="alert">
                      <h5><i class="fas fa-info"></i> Note:</h5>
                      <?= $this->session->flashdata('message'); ?>
                    </div>
                  </div>
                  <!--/. Col -->
                </div>
              <?php endif ;?>             
            </div><!-- /.container-fluid -->
          </div>
          <!-- /.content-header -->

          <!-- Main content -->
          <section class="content ">
            <div class="container-fluid col-sm-8">
              <!-- Default box -->
              <div class="card card-outline card-info">
                <div class="card-header">
                  <h4 class="card-title " text-align="center"><strong><?= $page; ?></strong></h4>
                  <a class="btn btn-secondary btn-sm float-right" href="<?php echo base_url('Admin/dataListSimpananpokok');?>">
                    <i class="fas fa-arrow-left"></i>&ensp;Back
                  </a>
                </div>
                <div class="card-body">

                  <form action="<?= base_url('Admin/dataListSimpananpokokEdit/'.$this->encrypt->encode($datasimpananpokok->id).'')?>" method="post">

                    <input type="hidden" name="id" value="<?= $datasimpananpokok->id ;?>">

                    <!-- form-group -->
                    <div class="form-group">
                      <label for="tanggal">Tanggal Simpanan Pokok</label>
                      <input type="date" name="tanggal" class="form-control" id="tanggal" value="<?= $datasimpananpokok->tgl ;?>">
                      <?= form_error('tanggal', '<small class="text-danger pl-3">', '</small>');?>
                    </div>
                    <!-- /.form-group -->

                    <!-- Kategori -->
                    <div class="form-group">
                      <label for="id_anggota" class="col-form-label">Anggota</label>
                      <select name="id_anggota" id="id_anggota" class="form-control select2" style="width: 100%;" >
                        <option value="" selected>Pilih Salah Satu</option>
                        <?php
                        foreach ($anggotaAll as $anggota) {

                          if($anggota->id == $datasimpananpokok->id_anggota){
                            echo '<option value="'.$anggota->id.'" selected="selected">'.$anggota->nama_karyawan.'</option>';

                          }else{

                            echo '<option value="'.$anggota->id.'">'.$anggota->nama_karyawan.'</option>';

                          }
                        }
                        ;?>
                      </select>
                      <?= form_error('id_anggota', '<small class="text-danger pl-3">', '</small>');?>
                    </div>
                    <!-- / Kategori -->

                    <!-- Jumlah-->
                    <div class="form-group">
                      <label for="jumlah" class="col-form-label">Jumlah Simpanan Pokok</label>
                      <input type="text" name="jumlah" class="form-control" id="jumlah" value="<?= $datasimpananpokok->jumlah ;?>">

                      <?= form_error('jumlah', '<small class="text-danger pl-3">', '</small>');?>
                    </div>
                    <!-- / jumlah -->

                    <div class="form-group text-right">
                      <button type="submit" class="btn btn-warning btn-sm ">Update &ensp;<i class="fas fa-edit"></i></button>
                    </div> 

                  </form>

                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.Container Fluid -->
          </section>
          <!-- /.content -->
          
        </div>