        <div class="content-wrapper">
          <!-- Content Header (Page header) -->
          <div class="content-header">
            <div class="container-fluid">
              <div class="row mb-2">
                <div class="col-sm-6">
                  <h1 class="m-0 text-dark"><?= $page ;?></h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                  <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><small><?= $this->session->userdata('level');?></small></li>
                    <li class="breadcrumb-item"><a href="<?= base_url('admin/dataListAngsuran');?>"><small><?= $parent ;?></small></a></li>
                    <li class="breadcrumb-item"><a href="<?= base_url('admin/dataListAngsuranAdd');?>"><small><?= $page ;?></small></a></li>
                  </ol>
                </div><!-- /.col -->
              </div><!-- /.row -->
              <?php if(validation_errors()) : ?>
                <!-- Row Note -->
                <div class="row">
                  <div class="col-12">
                    <div class="alert callout callout-info bg-danger" role="alert">
                      <h5><i class="fas fa-info"></i> Note:</h5>
                      <?= validation_errors(); ?>
                    </div>
                  </div>
                  <!--/. Col -->
                </div>
              <?php endif ;?>
              <?php if($this->session->flashdata('message') == TRUE) : ?>
                <!-- Row Note -->
                <div class="row">
                  <div class="col-12">
                    <div class="alert callout callout-info bg-danger" role="alert">
                      <h5><i class="fas fa-info"></i> Note:</h5>
                      <?= $this->session->flashdata('message'); ?>
                    </div>
                  </div>
                  <!--/. Col -->
                </div>
              <?php endif ;?>             
            </div><!-- /.container-fluid -->
          </div>
          <!-- /.content-header -->

          <!-- Main content -->
          <section class="content ">
            <div class="container-fluid col-sm-8">
              <!-- Default box -->
              <div class="card card-outline card-info">
                <div class="card-header">
                  <h4 class="card-title " text-align="center"><strong><?= $page; ?></strong></h4>
                  <a class="btn btn-secondary btn-sm float-right" href="<?php echo base_url('admin/dataListAngsuran');?>">
                    <i class="fas fa-arrow-left"></i>&ensp;Back
                  </a>
                </div>
                <div class="card-body">

                  <form action="<?= base_url('admin/dataListAngsuranAdd')?>" method="post">
 
                    <div class="form-group">
                      <label for="tanggal">Tanggal Angsuran</label>
                      <input type="date" name="tanggal" class="form-control" id="tanggal">
                      <?= form_error('tanggal', '<small class="text-danger pl-3">', '</small>');?>
                    </div>
                    
                    <div class="form-group">
                      <label for="id_pinjaman" class="col-form-label">Nama Anggota</label>
                      <select name="id_pinjaman" id="id_pinjaman" class="form-control select2 cari_ak" style="width: 100%;" >
                        <option value="" selected>Pilih Salah Satu</option>
                        <?php
                        foreach ($anggotaAll as $anggota) {
                          echo '<option value="'.$anggota->id.'" ak="'.$anggota->angsuran_ke.'" ja="'.$anggota->jumlah_angsuran.'">'.$anggota->nama_karyawan.' | '.$anggota->tanggal.' | '.$anggota->jumlah_pinjaman.'</option>';
                        }
                        ;?>
                      </select>
                      <?= form_error('id_anggota', '<small class="text-danger pl-3">', '</small>');?>
                    </div>
                    
                    <div class="form-group">
                      <label>Angsuran Ke-</label>
                      <input type="text" name="angsuran_ke" class="form-control" id="angsuran_ke" readonly>
                      <?= form_error('angsuran_ke', '<small class="text-danger pl-3">', '</small>');?>
                    </div>

                    <div class="form-group">
                      <label for="jumlah_angsuran">Jumlah Angsuran</label>
                      <input type="text" name="jumlah_angsuran" class="form-control" id="jumlah_angsuran" readonly>
                      <?= form_error('jumlah_angsuran', '<small class="text-danger pl-3">', '</small>');?>
                    </div>

                    <div class="form-group text-right">
                      <a class="btn btn-danger btn-sm" href="<?= base_url('admin/dataListAngsuranAdd');?>"><i class="fa fa-undo"></i>&ensp;Reset</a>
                      <button type="submit" class="btn btn-primary btn-sm ">Submit &ensp;<i class="fas fa-arrow-right"></i></button>
                    </div> 

                  </form>

                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.Container Fluid -->
          </section>
          <!-- /.content -->
          
        </div>