  <footer class="main-footer">
    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved
		
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.0
    </div>
  </footer>
