    <aside class="main-sidebar sidebar-dark-primary elevation-4">
      <!-- Brand Logo -->
      <a href="<?= base_url('Admin');?>" class="brand-link">
        <img src="<?= base_url('assets/');?>images/icon.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
        style="opacity: .8">
        <span class="brand-text font-weight-light">Administrator</span>
      </a>

      <!-- Sidebar -->
      <div class="sidebar">

        <!-- Sidebar Menu -->
        <nav class="mt-2">
          <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
           with font-awesome or any other icon font library -->
           <li class="nav-header">Main Navigation</li>
           <li class="nav-item">
            <a href="<?= base_url('Admin')?>" class="nav-link <?php if($page == 'Dashboard' || $page == 'Detail Pelanggaran'){echo 'active';} ?>">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?= base_url('Admin/dataListAnggota')?>" class="nav-link <?php if($parent == 'Data Anggota'){echo 'active';} ?>">
              <i class="nav-icon fas fa-user"></i>
              <p>
                Anggota
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?= base_url('Admin/dataListSimpananpokok')?>" class="nav-link <?php if($parent == 'Data Simpanan Pokok'){echo 'active';} ?>">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Simpanan Pokok
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?= base_url('Admin/dataListSimpananwajib')?>" class="nav-link <?php if($parent == 'Data Simpanan Wajib'){echo 'active';} ?>">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Simpanan Wajib
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?= base_url('Admin/dataListSimpanansukarela')?>" class="nav-link <?php if($parent == 'Data Simpanan Sukarela'){echo 'active';} ?>">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Simpanan Sukarela
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?= base_url('Admin/dataListPinjaman')?>" class="nav-link <?php if($parent == 'Data Pinjaman'){echo 'active';} ?>">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Pinjaman
              </p>
            </a>
          </li>

          <li class="nav-item">
            <a href="<?= base_url('Admin/dataListAngsuran')?>" class="nav-link <?php if($parent == 'Data Angsuran'){echo 'active';} ?>">
              <i class="nav-icon fas fa-book"></i>
              <p>
                Angsuran
              </p>
            </a>
          </li>

          <li class="nav-item has-treeview <?php if($parent == 'Laporan' || $parent == 'Data Laporan' || $parent == 'Website'){echo 'menu-open';} ?>">
            <a href="#" class="nav-link <?php if($parent == 'Laporan' || $parent == 'Data Laporan' || $parent == 'Website'){echo 'active';} ?>">
              <i class="nav-icon fas fa-cog"></i>
              <p>
                Laporan
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?= base_url('Admin/laporanSimpananpokok') ;?>" class="nav-link <?php if($page == 'Data Laporan Simpanan Pokok'){echo 'active';} ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Simpanan Pokok</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?= base_url('Admin/laporanSimpananwajib') ;?>" class="nav-link <?php if($page == 'Data Laporan Simpanan Wajib'){echo 'active';} ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Simpanan Wajib</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?= base_url('Admin/laporanSimpanansukarela') ;?>" class="nav-link <?php if($page == 'Data Laporan Simpanan Sukarela'){echo 'active';} ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Simpanan Sukarela</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?= base_url('Admin/laporanSimpanananggota') ;?>" class="nav-link <?php if($page == 'Data Laporan Simpanan Anggota'){echo 'active';} ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Simpanan Anggota</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?= base_url('Admin/laporanPinjaman') ;?>" class="nav-link <?php if($page == 'Data Laporan Pinjaman'){echo 'active';} ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Pinjaman</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?= base_url('Admin/laporanPinjamanAnggota') ;?>" class="nav-link <?php if($page == 'Data Laporan Pinjaman Anggota'){echo 'active';} ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Pinjaman Anggota</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="<?= base_url('Admin/laporanAngsuran') ;?>" class="nav-link <?php if($page == 'Data Laporan Angsuran'){echo 'active';} ?>">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Angsuran</p>
                </a>
              </li>

            </ul>
          </li>
          
          <li class="nav-item">
            <a href="#" class="nav-link" data-toggle="modal" data-target="#logOutModal">
              <i class="nav-icon fa-fw fas fa-sign-out-alt"></i>
              <p>
                Logout
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>